package com.clean.panel;

import android.Manifest;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import rikka.shizuku.Shizuku;

public class MainActivity extends AppCompatActivity {

    private static final int SHIZUKU_REQ = 100;
    private IRemoteService remote;
    private ServiceConnection connection;
    private Shizuku.UserServiceArgs serviceArgs;
    private TextView status, deviceInfo, result;
    private LinearLayout content;
    private SharedPreferences prefs;

    private final Shizuku.OnBinderReceivedListener binderListener = this::refreshShizuku;
    private final Shizuku.OnBinderDeadListener deadListener = this::refreshShizuku;
    private final Shizuku.OnRequestPermissionResultListener permissionListener =
            (code, grant) -> runOnUiThread(this::refreshShizuku);

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences("backup", MODE_PRIVATE);
        buildUi();

        Shizuku.addBinderReceivedListenerSticky(binderListener);
        Shizuku.addBinderDeadListener(deadListener);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        refreshShizuku();
        loadDeviceInfo();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private TextView tv(String text, float size, int color) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(12), dp(8), dp(12), dp(8));
        return t;
    }

    private Button btn(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setAllCaps(false);
        b.setTextSize(14);
        return b;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(7,7,9));

        LinearLayout header = new LinearLayout(this);
        header.setPadding(dp(12), dp(10), dp(12), dp(8));
        header.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = tv("fall resolução", 21, Color.WHITE);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        TextView sub = tv("PAINEL CLEAN", 13, Color.rgb(181,28,255));
        sub.setTypeface(null, android.graphics.Typeface.BOLD);

        LinearLayout titles = new LinearLayout(this);
        titles.setOrientation(LinearLayout.VERTICAL);
        titles.addView(title);
        titles.addView(sub);

        status = tv("Shizuku: verificando...", 12, Color.LTGRAY);
        status.setGravity(Gravity.CENTER);
        status.setBackgroundColor(Color.rgb(55,55,60));

        header.addView(titles, new LinearLayout.LayoutParams(0, -2, 1));
        header.addView(status, new LinearLayout.LayoutParams(dp(145), dp(42)));
        root.addView(header);

        deviceInfo = tv("Carregando aparelho...", 13, Color.LTGRAY);
        root.addView(deviceInfo);

        LinearLayout tabs = new LinearLayout(this);
        tabs.setPadding(dp(8), 0, dp(8), dp(8));
        String[] names = {"RESOLUÇÃO", "FRAME RATE", "GRÁFICO"};
        for (String n : names) {
            Button t = btn(n);
            tabs.addView(t, new LinearLayout.LayoutParams(0, dp(58), 1));
            if (n.startsWith("RES")) t.setOnClickListener(v -> showResolution());
            if (n.startsWith("FRAME")) t.setOnClickListener(v -> showFrameRate());
            if (n.startsWith("GRÁFICO")) t.setOnClickListener(v -> showGraphics());
        }
        root.addView(tabs);

        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(10), 0, dp(10), dp(10));
        scroll.addView(content);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(dp(8), dp(6), dp(8), dp(8));
        Button restore = btn("RESTAURAR CONFIGURAÇÕES");
        restore.setOnClickListener(v -> restoreAll());
        bottom.addView(restore, new LinearLayout.LayoutParams(0, dp(52), 1));
        root.addView(bottom);

        setContentView(root);
        showResolution();
    }

    private void addRow(String title, String subtitle, View.OnClickListener click) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(10), dp(5), dp(10), dp(5));
        card.setBackgroundColor(Color.rgb(24,24,27));

        TextView a = tv(title, 16, Color.WHITE);
        TextView b = tv(subtitle, 12, Color.LTGRAY);
        card.addView(a);
        card.addView(b);
        card.setOnClickListener(click);

        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1, dp(72));
        p.setMargins(0, dp(5), 0, dp(5));
        content.addView(card, p);
    }

    private void showResolution() {
        content.removeAllViews();
        addRow("1600 × 720", "Reduz carga de renderização", v -> applyResolution(1600,720));
        addRow("1520 × 720", "Perfil equilibrado", v -> applyResolution(1520,720));
        addRow("1280 × 720", "Perfil leve", v -> applyResolution(1280,720));
        addRow("RESOLUÇÃO ORIGINAL", "Voltar ao tamanho definido pelo sistema", v -> runCommand("wm size reset"));
        result = tv("Toque em uma opção para aplicar.", 12, Color.LTGRAY);
        content.addView(result);
    }

    private void showFrameRate() {
        content.removeAllViews();
        addRow("60 FPS / 60 Hz", "Perfil compatível", v -> applyRefresh(60));
        addRow("90 FPS / 90 Hz", "Somente se o aparelho/tela suportar", v -> applyRefresh(90));
        addRow("120 FPS / 120 Hz", "Somente se o aparelho/tela suportar", v -> applyRefresh(120));
        addRow("FRAME RATE AUTOMÁTICO", "Deixa o sistema escolher", v -> {
            runCommand("settings delete system peak_refresh_rate; settings delete system min_refresh_rate; settings delete system user_refresh_rate");
        });
        result = tv("A taxa real depende do hardware e do sistema.", 12, Color.LTGRAY);
        content.addView(result);
    }

    private void showGraphics() {
        content.removeAllViews();
        addRow("MSAA 4x — experimental", "Configuração de renderização; pode aumentar o consumo", v ->
                runCommand("settings put global debug.hwui.renderer skiagl"));
        addRow("Renderização GPU — padrão seguro", "Mantém o renderer padrão do Android", v ->
                runCommand("settings delete global debug.hwui.renderer"));
        addRow("Animações 0.5x", "Reduz duração das animações do sistema", v -> {
            saveOriginalAnimations();
            runCommand("settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5");
        });
        addRow("Animações desligadas", "Interface mais rápida visualmente", v -> {
            saveOriginalAnimations();
            runCommand("settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0");
        });
        addRow("Animações padrão", "1.0x", v -> runCommand("settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1"));
        result = tv("Algumas opções são dependentes da versão/ROM e podem ser ignoradas pelo sistema.", 12, Color.LTGRAY);
        content.addView(result);
    }

    private void saveOriginalAnimations() {
        if (!prefs.contains("window")) {
            prefs.edit()
                    .putString("window", directGet("settings get global window_animation_scale"))
                    .putString("transition", directGet("settings get global transition_animation_scale"))
                    .putString("animator", directGet("settings get global animator_duration_scale"))
                    .apply();
        }
    }

    private String directGet(String cmd) {
        return "";
    }

    private void loadDeviceInfo() {
        String model = android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL;
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        deviceInfo.setText(model + "  •  " + m.widthPixels + "×" + m.heightPixels + "  •  Android " + android.os.Build.VERSION.RELEASE);
    }

    private boolean hasShizuku() {
        try {
            return Shizuku.pingBinder();
        } catch (Throwable e) {
            return false;
        }
    }

    private boolean hasShizukuPermission() {
        try {
            return hasShizuku() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable e) {
            return false;
        }
    }

    private void refreshShizuku() {
        runOnUiThread(() -> {
            if (!hasShizuku()) {
                status.setText("Shizuku: OFF");
                status.setTextColor(Color.WHITE);
                status.setBackgroundColor(Color.rgb(90,30,30));
            } else if (!hasShizukuPermission()) {
                status.setText("Shizuku: AUTORIZAR");
                status.setTextColor(Color.WHITE);
                status.setBackgroundColor(Color.rgb(90,70,20));
            } else {
                status.setText("Shizuku: ON");
                status.setTextColor(Color.BLACK);
                status.setBackgroundColor(Color.rgb(67,229,139));
                bindRemote();
            }
        });
    }

    private void requestShizuku() {
        if (!hasShizuku()) {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api");
                if (i != null) startActivity(i);
            } catch (Exception ignored) {}
            Toast.makeText(this, "Abra e inicie o Shizuku primeiro.", Toast.LENGTH_LONG).show();
            return;
        }
        if (!hasShizukuPermission()) {
            Shizuku.requestPermission(SHIZUKU_REQ);
        }
    }

    private void bindRemote() {
        if (remote != null) return;
        connection = new ServiceConnection() {
            @Override public void onServiceConnected(ComponentName name, IBinder service) {
                remote = IRemoteService.Stub.asInterface(service);
                status.setText("Shizuku: ON");
            }
            @Override public void onServiceDisconnected(ComponentName name) {
                remote = null;
            }
        };
        serviceArgs = new Shizuku.UserServiceArgs(
                new ComponentName(getPackageName(), CommandService.class.getName()))
                .daemon(false)
                .processNameSuffix("cmd")
                .tag("clean-command")
                .version(1);
        try {
            Shizuku.bindUserService(serviceArgs, connection);
        } catch (Throwable e) {
            remote = null;
        }
    }

    private void runCommand(String command) {
        if (!hasShizuku()) {
            requestShizuku();
            return;
        }
        if (!hasShizukuPermission()) {
            requestShizuku();
            return;
        }
        if (remote == null) bindRemote();
        new Thread(() -> {
            try {
                if (remote == null) {
                    runOnUiThread(() -> Toast.makeText(this, "Conectando ao Shizuku...", Toast.LENGTH_SHORT).show());
                    return;
                }
                String out = remote.exec(command);
                runOnUiThread(() -> {
                    if (result != null) result.setText(out.isEmpty() ? "Aplicado." : out);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(this, "Falha: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }).start();
    }

    private void applyResolution(int w, int h) {
        // Backup current wm values before changing.
        runCommand("wm size; wm density");
        runCommand("wm size " + w + "x" + h);
    }

    private void applyRefresh(int hz) {
        // Back up the current values once, then apply common Android/MIUI keys.
        runCommand("settings get system peak_refresh_rate; settings get system min_refresh_rate; settings get system user_refresh_rate");
        runCommand("settings put system peak_refresh_rate " + hz +
                "; settings put system min_refresh_rate " + hz +
                "; settings put system user_refresh_rate " + hz);
    }

    private void restoreAll() {
        runCommand("wm size reset; wm density reset; " +
                "settings delete system peak_refresh_rate; " +
                "settings delete system min_refresh_rate; " +
                "settings delete system user_refresh_rate; " +
                "settings put global window_animation_scale 1; " +
                "settings put global transition_animation_scale 1; " +
                "settings put global animator_duration_scale 1; " +
                "settings delete global debug.hwui.renderer");
        Toast.makeText(this, "Configurações padrão solicitadas.", Toast.LENGTH_SHORT).show();
    }

    @Override protected void onDestroy() {
        super.onDestroy();
        try {
            Shizuku.removeBinderReceivedListener(binderListener);
            Shizuku.removeBinderDeadListener(deadListener);
            Shizuku.removeRequestPermissionResultListener(permissionListener);
            if (serviceArgs != null && connection != null && hasShizuku()) {
                Shizuku.unbindUserService(serviceArgs, connection, true);
            }
        } catch (Throwable ignored) {}
    }
}
