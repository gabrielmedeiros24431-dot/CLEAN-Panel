package com.clean.panel;

import android.os.RemoteException;
import androidx.annotation.Keep;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.concurrent.TimeUnit;
import rikka.shizuku.UserService;

@Keep
public class CommandService extends IRemoteService.Stub {
    public CommandService() {}

    @Keep
    public CommandService(android.content.Context context) {}

    @Override
    public String exec(String command) throws RemoteException {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"sh", "-c", command});
            StringBuilder out = new StringBuilder();
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                out.append(line).append('\n');
            }
            BufferedReader er = new BufferedReader(new InputStreamReader(p.getErrorStream()));
            while ((line = er.readLine()) != null) {
                out.append(line).append('\n');
            }
            p.waitFor(8, TimeUnit.SECONDS);
            return out.toString().trim();
        } catch (Exception e) {
            return "ERROR: " + e.getClass().getSimpleName() + ": " + e.getMessage();
        }
    }

    public void destroy() {
        System.exit(0);
    }
}
