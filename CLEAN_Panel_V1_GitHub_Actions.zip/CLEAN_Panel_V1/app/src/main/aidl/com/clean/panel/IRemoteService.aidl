package com.clean.panel;

interface IRemoteService {
    String exec(String command);
}
