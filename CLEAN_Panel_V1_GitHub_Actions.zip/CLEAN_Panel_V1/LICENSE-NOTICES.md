Este projeto usa a Shizuku API, publicada sob licença MIT pela RikkaApps.
A dependência é obtida do Maven Central durante a compilação.
Consulte o projeto oficial para os termos completos.
