# Compilar pelo GitHub Actions

1. Crie um repositório no GitHub.
2. Envie todos os arquivos desta pasta para o repositório.
3. Abra a aba **Actions**.
4. Selecione **Build CLEAN Panel APK**.
5. Clique em **Run workflow**.
6. Aguarde a execução terminar.
7. Abra a execução concluída e procure **Artifacts**.
8. Baixe **CLEAN-Panel-V1-debug**.
9. Dentro do ZIP estará `app-debug.apk`.

O workflow compila uma versão DEBUG. Para instalar no Android, extraia o APK do artifact e instale-o no aparelho.

Importante: o workflow compila o código Android nativo. O `index.html` não é necessário e não deve substituir o projeto Gradle.
