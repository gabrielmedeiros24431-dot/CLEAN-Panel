# CLEAN Panel V1

Painel Android inspirado na interface enviada no vídeo, com:

- Interface escura com destaque roxo.
- Abas RESOLUÇÃO / FRAME RATE / GRÁFICO.
- Integração oficial com Shizuku API 13.1.5.
- UserService do Shizuku para executar comandos shell com identidade ADB/root disponibilizada pelo Shizuku.
- Aplicação e restauração de `wm size`, `wm density`, refresh rate e escalas de animação.
- Modo degradado: o app abre e mostra informações mesmo sem Shizuku; alterações avançadas pedem Shizuku.

## Requisitos

- Android 6.0+.
- Para o modo avançado: Shizuku instalado e iniciado.
- Android 11+ permite iniciar o Shizuku pelo próprio aparelho usando Wireless Debugging.

## Compilar

Abra a pasta no Android Studio recente e execute:

`Build > Make Project`

Depois:

`Build > Build APK(s)`

O APK de debug ficará em:

`app/build/outputs/apk/debug/app-debug.apk`

## Observações importantes

1. O Android não garante que cada chave de sistema usada pelo painel exista em todas as ROMs.
2. `wm size` e `wm density` podem alterar a escala da interface. O botão RESTAURAR usa `wm size reset` e `wm density reset`.
3. A taxa de atualização depende do hardware/ROM. Uma ROM pode ignorar ou sobrescrever as chaves.
4. A opção de renderer/MSAA é marcada como experimental. Não promete ganho de FPS.
5. A API oficial do Shizuku informa que UserService é o caminho recomendado para tarefas complexas; `newProcess` está planejado para remoção na API 14, por isso esta V1 usa UserService.

## Personalização

As cores e textos ficam em `MainActivity.java` e `res/values/colors.xml`.
